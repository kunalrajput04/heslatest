import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';

import {
  DeviceInfoList,
  DeviceInformation,
  getDevice,
} from 'src/app/Models/device-information';
import { GetDT } from 'src/app/Models/get-dt';
import { GetFeeder } from 'src/app/Models/get-feeder';
import { GetSubdivision } from 'src/app/Models/get-subdivision';
import { DataService } from 'src/app/Services/data.service';
import { DeviceService } from 'src/app/Services/device.service';
import { DTService } from 'src/app/Services/dt.service';
import { FeederService } from 'src/app/Services/feeder.service';
import { SubDivisionService } from 'src/app/Services/sub-division.service';
import { SubStationService } from 'src/app/Services/sub-station.service';
import Swal from 'sweetalert2';
declare let $: any;

import { DataSharedService } from 'src/app/Services/data-shared.service';
import { Headernavigation } from 'src/app/Model/headernavigation';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { AuthService } from 'src/app/Services/auth.service';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-device-info',
  templateUrl: './device-info.component.html',
  styleUrls: ['./device-info.component.scss'],
})
export class DeviceInfoComponent implements OnInit {
  formdata: DeviceInformation = new DeviceInformation();
  isEdit: boolean = false;

  tableData: DeviceInfoList[] = [];
  fullData: DeviceInfoList[] = [];
  pageOfItems: Array<any>;

  searchText = null;
  subdivisionDropDown: any[] = [];
  substatioDropDown: any[] = [];
  feederDropDown: any[] = [];
  dtDropDown: any[] = [];
  deviceno: getDevice = new getDevice();
  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject<any>();
  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;
  persons: any;
  data: Headernavigation = {
    firstlevel: '',
    menuname: 'Device & Info',
    url: '/deviceInfo',
  };
  iswritepermission: string;
  apiUrl:string=environment.apiUrl;
  constructor(
    private deviceservice: DeviceService,
    private spinner: NgxSpinnerService,
    private toaster: ToastrService,
    private subdivisionservice: SubDivisionService,
    private router: Router,
    private substation: SubStationService,
    private feederservice: FeederService,
    private dtservice: DTService,
    private datasharedservice: DataSharedService,
    private authservice: AuthService,
    private http: HttpClient
  ) {
    this.datasharedservice.chagneHeaderNav(this.data);
  }
  ngOnInit(): void {
    this.onTableget();
    this.dtOptions = {
      pageLength: 10,
      lengthMenu: [5, 10, 25, 50, 100, 500, 1000, 10000],
      dom: 'lBfrtip',
      scrollX: true,
      scrollY: '300px',
      scrollCollapse: true,
      buttons: ['print', 'excel'],
      serverSide: true,
      processing: true,
      ajax: (dataTablesParameters: any, callback) => {
        let searchkey = dataTablesParameters.search.value;
        let fullData = [];
        fullData = this.fullData.filter(
          (s) =>
            (s.consumerName != null &&
              s.consumerName.toLowerCase().includes(searchkey.toLowerCase())) ||
            (s.deviceSerialNo != null &&
              s.deviceSerialNo
                .toLowerCase()
                .includes(searchkey.toLowerCase())) ||
            (s.consumerNo != null &&
              s.consumerNo.toLowerCase().includes(searchkey.toLowerCase())) ||
            (s.meterType != null &&
              s.meterType.toLowerCase().includes(searchkey.toLowerCase())) ||
            (s.subDivisionName != null &&
              s.subDivisionName
                .toLowerCase()
                .includes(searchkey.toLowerCase())) ||
            (s.subStationName != null &&
              s.subStationName
                .toLowerCase()
                .includes(searchkey.toLowerCase())) ||
            (s.feederName != null &&
              s.feederName.toLowerCase().includes(searchkey.toLowerCase())) ||
            (s.ipAddressMain != null &&
              s.ipAddressMain
                .toLowerCase()
                .includes(searchkey.toLowerCase())) ||
            (s.latitude != null &&
              s.latitude.toLowerCase().includes(searchkey.toLowerCase())) ||
            (s.longitude != null &&
              s.longitude.toLowerCase().includes(searchkey.toLowerCase()))
        );
        fullData.sort((a, b) => a.consumerName.localeCompare(b.consumerName));
        this.tableData = fullData.slice(
          dataTablesParameters.start,
          dataTablesParameters.length + dataTablesParameters.start
        );
        callback({
          recordsTotal: fullData.length,
          recordsFiltered: fullData.length,
          data: this.tableData,
        });
      },
      columns: [
        { data: 'consumerName' },
        { data: 'deviceSerialNo', name: 'CustomerNo' },
        { data: 'consumerNo', name: 'CustomerName' },
        { data: 'meterType' },
        { data: 'subDivisionName', name: 'Created' },
        { data: 'subStationName' },
        { data: 'feederName', name: 'MeterSerialNumber' },
        { data: 'nicMsisdnNo', name: 'BoxSealNo' },
        { data: 'ipAddressMain', name: 'GprsSealNo' },
        { data: 'latitude', name: 'MeterSealNo' },
        { data: 'longitude' },
      ],
    };
    this.iswritepermission = localStorage.getItem('WriteAccess');
  }
  onTableget() {
    this.spinner.show();

    this.deviceservice.getDeviceList().subscribe((res: any) => {
      if (res != null && res.message != 'Key Is Not Valid') {
        //this.headerdata = res.data[0][1];
        for (let item in res.data[0]) {
          if (parseInt(item) !== 1) {
            this.fullData.push({
              consumerName: res.data[0][item][0],
              deviceSerialNo: res.data[0][item][1],
              consumerNo: res.data[0][item][2],
              meterType: res.data[0][item][3],
              subDivisionName: res.data[0][item][4],
              subStationName: res.data[0][item][5],
              feederName: res.data[0][item][6],
              nicMsisdnNo: res.data[0][item][7],
              ipAddressMain: res.data[0][item][8],
              latitude: res.data[0][item][9],
              longitude: res.data[0][item][10],
            });
          }
        }
        this.fullData.sort((a, b) =>
          a.consumerName.localeCompare(b.consumerName)
        );
        this.tableData = this.fullData.slice(0, 10);
        this.rerender();
        this.spinner.hide();
        localStorage.setItem('apikey', res.apiKey);
      } else {
        this.spinner.hide();
        this.logout();
      }
    });
  }

  // lazyLoadData(data: any) {
  //   let datalength = 500;

  //   setTimeout(() => {
  //     console.log(datalength);
  //     while (data.length > datalength) {
  //       this.rowdata = data.slice(0, datalength);
  //       console.log(this.rowdata);
  //       console.log(data);
  //       datalength = datalength + 500;
  //       this.rerender();
  //     }
  //   }, 100);
  // }
  logout() {
    this.authservice.logout();
    sessionStorage.removeItem('IsReload');
    this.router.navigate(['/login']);
  }
  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }
  rerender(): void {
    //this.onTableget();
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.draw();
    });
  }

  showDeviceModal() {
    $('#ModalAddDevice').modal('show');
    this.isEdit = false;
    this.formdata = new DeviceInformation();
    this.getSubdivision();
  }
  getSubdivision() {
    this.spinner.show();

    this.subdivisionservice.getSubdivision().subscribe((res: any) => {
      if (res != null) {
        this.subdivisionDropDown = [];
        let obj = res.data[0];
        for (var item in obj) {
          this.subdivisionDropDown.push(obj[item][0]);
        }
        this.spinner.hide();
      }
    });
  }

  getSubstation(subdivision: string) {
    this.spinner.show();
    this.substation
      .getSubstationBySubdivision(subdivision)
      .subscribe((res: any) => {
        this.spinner.hide();
        this.substatioDropDown = [];
        if (res.data != null) {
          let obj = res.data[0];
          for (var item in obj) {
            this.substatioDropDown.push(obj[item][0]);
          }
        }
      });
  }
  getFeeder(substation: string) {
    this.spinner.show();
    this.feederservice
      .getFeederBySubstation(substation)
      .subscribe((res: any) => {
        this.spinner.hide();
        this.feederDropDown = [];
        if (res.data != null) {
          let obj = res.data[0];
          for (var item in obj) {
            this.feederDropDown.push(obj[item][0]);
          }
        }
      });
  }
  getDT(feeder: string) {
    this.spinner.show();
    this.dtservice.getDTByFeeder(feeder).subscribe((res: any) => {
      this.spinner.hide();
      this.dtDropDown = [];
      if (res.data != null) {
        let obj = res.data[0];
        for (var item in obj) {
          this.dtDropDown.push(obj[item][0]);
        }
      }
    });
  }

  deleteDeviceInfo(meterno: string) {
    Swal.fire({
      title: 'Are you sure?',
      input: 'text',
      inputAttributes: {
        autocapitalize: 'off',
      },

      text: 'You will not be able to recover this data! Enter your reason',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
    }).then((result) => {
      if (result.value == '') {
        Swal.fire('Please Enter Delete Reason!', '', 'error');
      } else if (result.isConfirmed) {
        this.deviceservice
          .deleteDevice(meterno, result.value)
          .subscribe((res: any) => {
            if (res != null) {
              this.spinner.hide();
              Swal.fire('Deleted Successfully', '', 'success');
              localStorage.setItem('apikey', res.apiKey);
              //this.rerender();
            }
          });
      }
    });
  }

  saveDevice(form: NgForm) {
    $('#ModalAddDevice').modal('hide');
    this.spinner.show();
    if (form.value != null) {
      this.deviceservice.AddDevice(form.value).subscribe((res: any) => {
        if (res != null) {
          if (res.data == true) {
            if (this.isEdit) {
              this.spinner.hide();
              this.toaster.success('Updated Successfully');
              // this.rerender();
            } else {
              this.spinner.hide();
              //this.rerender();
              this.toaster.success('Created Successfully');
            }
          }
        } else {
          alert('Oops!! something went wrong');
        }
      });
    }
  }

  getDeviceInfo(meterno: string) {
    this.getSubdivision();
    this.deviceno.deviceNo = meterno;
    this.spinner.show();
    this.deviceservice.getDeviceInfo(this.deviceno).subscribe((res: any) => {
      this.isEdit = true;
      this.spinner.hide();
      if (res.data != null) {
        this.formdata.ownerName = res.data.owner_name;
        this.formdata.subDivisionName = res.data.subdevision_name;
        this.getSubstation(this.formdata.subDivisionName);
        this.formdata.subStationName = res.data.substation_name;
        this.getFeeder(this.formdata.subStationName);
        this.formdata.feederName = res.data.feeder_name;
        this.getDT(this.formdata.feederName);

        this.formdata.dtName = res.data.dt_name;
        this.formdata.deviceSerialNo = meterno;
        this.formdata.commissioningStatus = res.data.commissioning_status;
        this.formdata.consumerName = res.data.consumer_name;
        this.formdata.consumerNo = res.data.consumer_no;
        this.formdata.phoneNumber = res.data.phone_number;
        this.formdata.latitude = res.data.latitude;
        this.formdata.longitude = res.data.longitude;
        this.formdata.deviceType = res.data.device_type;
        this.formdata.ipAddressMain = res.data.ip_address_main;
        this.formdata.address = res.data.address;
        this.formdata.ipPortMain = res.data.ip_port_main;
        this.formdata.manufacturer = res.data.manufacturer;

        $('#ModalAddDevice').modal('show');
        localStorage.setItem('apikey', res.apiKey);
      } else {
        this.toaster.error('Oops!! something went wrong');
      }
    });
  }

  onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
  }
}
